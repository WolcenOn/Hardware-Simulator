export const catalog = {
  components: {
    case_atx_001: {
      id: 'case_atx_001', type: 'case', displayName: 'Caja ATX abierta', summary: 'Chasis de prácticas con separadores y panel lateral retirado.', targetSlot: 'case', compatible: { formFactors: ['ATX', 'Micro-ATX'] }, electrical: { peakWatts: 0 }
    },
    mb_b650_atx_001: {
      id: 'mb_b650_atx_001', type: 'motherboard', displayName: 'Placa base B650 ATX', summary: 'Socket AM5, DDR5, SATA, M.2 y PCIe x16.', targetSlot: 'case_motherboard_tray', compatible: { socket: 'AM5', memoryType: 'DDR5', formFactor: 'ATX', chipset: 'B650' }, electrical: { peakWatts: 45 }, ports: ['ATX_24_PIN', 'EPS_CPU_8_PIN', 'SATA_DATA']
    },
    cpu_ryzen5_7600: {
      id: 'cpu_ryzen5_7600', type: 'cpu', displayName: 'AMD Ryzen 5 7600', summary: 'CPU AM5 de 65 W, ideal para explicar socket y refrigeración.', targetSlot: 'cpu_socket', compatible: { socket: 'AM5', memoryType: 'DDR5' }, electrical: { typicalWatts: 65, peakWatts: 88 }, thermal: { idleC: 38, loadC: 75, maxSafeC: 95 }
    },
    cooler_basic_am5: {
      id: 'cooler_basic_am5', type: 'cooler', displayName: 'Disipador AM5 básico', summary: 'Requiere pasta térmica correcta y anclaje firme.', targetSlot: 'cpu_socket', compatible: { socket: 'AM5' }, electrical: { peakWatts: 3 }, thermal: { coolingCapacityWatts: 95 }
    },
    ram_ddr5_16gb_5600: {
      id: 'ram_ddr5_16gb_5600', type: 'ram', displayName: 'RAM DDR5 16 GB', summary: 'Módulo DDR5; debe encajar en el slot A2 con clips cerrados.', targetSlot: 'dimm_a2', compatible: { memoryType: 'DDR5', capacityGb: 16, speedMhz: 5600 }, electrical: { peakWatts: 8 }
    },
    gpu_rx_7600: {
      id: 'gpu_rx_7600', type: 'gpu', displayName: 'GPU PCIe RX 7600', summary: 'Tarjeta gráfica con conector PCIe de 8 pines.', targetSlot: 'pcie_x16_1', compatible: { slot: 'PCIe_x16' }, electrical: { typicalWatts: 165, peakWatts: 190, requiredConnectors: ['PCIE_GPU_8_PIN'] }
    },
    ssd_sata_1tb: {
      id: 'ssd_sata_1tb', type: 'storage', displayName: 'SSD SATA 1 TB', summary: 'Necesita cable SATA de datos y alimentación SATA.', targetSlot: 'sata_data_1', compatible: { storageInterface: 'SATA' }, electrical: { peakWatts: 6 }, healthModel: { smartStatus: 'good', badSectors: 0, wearLevelPercent: 8 }
    },
    psu_450w_bronze: {
      id: 'psu_450w_bronze', type: 'psu', displayName: 'Fuente 450 W Bronze', summary: 'Fuente limitada: útil para provocar sobrecarga con GPU.', targetSlot: 'psu_bay', compatible: { formFactor: 'ATX_PSU' }, electrical: { maxWatts: 450, peakWatts: 0, connectors: ['ATX_24_PIN', 'EPS_CPU_8_PIN', 'SATA_POWER', 'PCIE_GPU_8_PIN'] }, diagnostics: { voltages: { '12V': [11.4, 12.6], '5V': [4.75, 5.25], '3.3V': [3.135, 3.465] } }
    },
    psu_750w_gold: {
      id: 'psu_750w_gold', type: 'psu', displayName: 'Fuente 750 W Gold', summary: 'Fuente con margen suficiente para un montaje gaming medio.', targetSlot: 'psu_bay', compatible: { formFactor: 'ATX_PSU' }, electrical: { maxWatts: 750, peakWatts: 0, connectors: ['ATX_24_PIN', 'EPS_CPU_8_PIN', 'SATA_POWER', 'PCIE_GPU_8_PIN', 'PCIE_GPU_8_PIN'] }
    }
  },
  slots: {
    case: { accepts: ['case'] },
    case_motherboard_tray: { accepts: ['motherboard'] },
    cpu_socket: { accepts: ['cpu', 'cooler'] },
    dimm_a2: { accepts: ['ram'] },
    pcie_x16_1: { accepts: ['gpu'] },
    sata_data_1: { accepts: ['storage'] },
    psu_bay: { accepts: ['psu'] }
  },
  diagnosticTools: {
    visual_inspection: 'Inspección visual',
    bios_beep_decoder: 'Decodificador de pitidos BIOS',
    multimeter: 'Multímetro virtual',
    smart_tool: 'Herramienta SMART',
    stress_test: 'Prueba de estrés'
  }
};

export const faultLibrary = {
  ram_not_seated: {
    id: 'ram_not_seated', type: 'assembly_error', severity: 'blocking', targetType: 'ram',
    symptoms: { post: false, boot: false, display: false, beepCode: '3 pitidos cortos', debugLed: 'DRAM' },
    tools: {
      visual_inspection: 'El módulo RAM está ligeramente levantado: un clip no está cerrado.',
      bios_beep_decoder: 'Patrón detectado: 3 pitidos cortos. Probable error de memoria.',
      multimeter: 'Las tensiones principales son correctas; el problema no apunta a la fuente.',
      stress_test: 'No se puede ejecutar: el equipo no completa POST.'
    },
    resolution: 'Reencajar la RAM hasta que ambos clips cierren.'
  },
  cpu_eps_missing: {
    id: 'cpu_eps_missing', type: 'connection_error', severity: 'blocking', targetType: 'motherboard',
    symptoms: { post: false, boot: false, display: false, beepCode: null, debugLed: 'CPU' },
    tools: {
      visual_inspection: 'El conector EPS de CPU de 8 pines está sin conectar.',
      multimeter: 'La fuente entrega 12 V, pero la CPU no recibe alimentación en el conector EPS.',
      bios_beep_decoder: 'No hay pitidos útiles: el POST no llega a inicializar CPU.',
      stress_test: 'No se puede ejecutar: el equipo no completa POST.'
    },
    resolution: 'Conectar el cable EPS CPU 8 pin desde la fuente a la placa.'
  },
  sata_data_disconnected: {
    id: 'sata_data_disconnected', type: 'connection_error', severity: 'blocking', targetType: 'storage',
    symptoms: { post: true, boot: false, screenMessage: 'No bootable device' },
    tools: {
      visual_inspection: 'El SSD tiene alimentación, pero el cable SATA de datos no está conectado.',
      smart_tool: 'El disco no aparece: no puede leerse SMART si la BIOS no detecta el dispositivo.',
      bios_beep_decoder: 'Sin pitidos de hardware crítico: el problema aparece en fase de arranque.',
      multimeter: 'La alimentación SATA es correcta.'
    },
    resolution: 'Conectar cable SATA de datos a la placa y al SSD.'
  },
  bad_thermal_paste: {
    id: 'bad_thermal_paste', type: 'thermal_fault', severity: 'critical', targetType: 'cpu',
    symptoms: { post: true, boot: true, idleTempC: 76, loadTempC: 106, thermalShutdown: true },
    tools: {
      visual_inspection: 'La pasta térmica está mal distribuida; hay zonas de la CPU sin contacto.',
      stress_test: 'La CPU supera 100 °C y el sistema se apaga por protección térmica.',
      multimeter: 'Las tensiones de la fuente son estables.',
      smart_tool: 'El almacenamiento no muestra errores SMART.'
    },
    resolution: 'Limpiar y reaplicar pasta térmica en cantidad adecuada.'
  },
  psu_overload: {
    id: 'psu_overload', type: 'electrical_fault', severity: 'critical', targetType: 'psu',
    symptoms: { post: true, boot: 'unstable', shutdownUnderLoad: true },
    tools: {
      visual_inspection: 'No se aprecian cables sueltos. El montaje parece correcto.',
      multimeter: 'La línea de 12 V cae bajo carga: posible sobrecarga de la fuente.',
      stress_test: 'El sistema se apaga cuando CPU y GPU entran en carga alta.',
      bios_beep_decoder: 'Sin patrón de pitidos: el fallo aparece bajo carga, no en POST.'
    },
    resolution: 'Sustituir por una fuente con margen suficiente, idealmente consumo pico × 1,25.'
  },
  bad_sectors: {
    id: 'bad_sectors', type: 'storage_fault', severity: 'major', targetType: 'storage',
    symptoms: { post: true, boot: 'slow', osPerformance: 'very_slow', blueScreenChance: 0.25 },
    tools: {
      smart_tool: 'SMART muestra sectores reasignados y pendientes. Riesgo de pérdida de datos.',
      stress_test: 'CPU/GPU estables; la lentitud aparece al leer/escribir en disco.',
      visual_inspection: 'Cableado correcto. No parece una desconexión física.',
      multimeter: 'Alimentación SATA dentro de rango.'
    },
    resolution: 'Sustituir el disco y recuperar datos si es posible.'
  }
};

export const guidedBuild = ['case_atx_001', 'mb_b650_atx_001', 'cpu_ryzen5_7600', 'cooler_basic_am5', 'ram_ddr5_16gb_5600', 'ssd_sata_1tb', 'gpu_rx_7600', 'psu_450w_bronze'];
