import { catalog, guidedBuild } from './data.js';
import { createInitialState, installComponent, performAction, runDiagnosticTool, powerOn, evaluateSystem, isInstalled } from './rulesEngine.js';

let state = createInitialState();
const $ = selector => document.querySelector(selector);
const $$ = selector => Array.from(document.querySelectorAll(selector));

const els = {
  list: $('#component-list'),
  template: $('#component-card-template'),
  scene: $('#scene'),
  orientation: $('#orientation-label'),
  log: $('#event-log'),
  post: $('#post-status'),
  boot: $('#boot-status'),
  watts: $('#watts-status'),
  temp: $('#temp-status'),
  score: $('#score-label'),
  modeLabel: $('#mode-label'),
  assemblyButton: $('#btn-assembly'),
  diagnosticButton: $('#btn-diagnostic'),
  cablesLayer: $('#cables-layer')
};

function render() {
  renderComponents();
  renderScene();
  renderInspector();
}

function renderComponents() {
  els.list.innerHTML = '';
  guidedBuild.forEach(id => {
    const component = catalog.components[id];
    const node = els.template.content.firstElementChild.cloneNode(true);
    node.classList.toggle('installed', isInstalled(state, component.type));
    node.querySelector('h3').textContent = component.displayName;
    node.querySelector('p').textContent = component.summary;
    const button = node.querySelector('button');
    const installed = isInstalled(state, component.type) && component.type !== 'psu';
    button.textContent = installed ? 'Instalado' : `Instalar`;
    button.disabled = installed;
    button.addEventListener('click', () => {
      installComponent(state, id);
      render();
    });
    els.list.appendChild(node);
  });

  const quickActions = document.createElement('article');
  quickActions.className = 'component-card';
  quickActions.innerHTML = `
    <div class="component-icon"></div>
    <div>
      <h3>Acciones de práctica</h3>
      <p>Corrige errores típicos o fuerza malas prácticas para observar consecuencias.</p>
      <button data-action="seat_ram" type="button">Reencajar RAM</button>
      <button data-action="connect_eps" type="button">Conectar CPU 8 pin</button>
      <button data-action="connect_sata" type="button">Conectar SATA datos</button>
      <button data-action="bad_paste" type="button">Aplicar mal la pasta</button>
      <button data-action="good_paste" type="button">Reaplicar pasta bien</button>
    </div>`;
  quickActions.querySelectorAll('button').forEach(btn => btn.addEventListener('click', () => {
    performAction(state, btn.dataset.action);
    render();
  }));
  els.list.appendChild(quickActions);
}

function renderScene() {
  els.scene.className = `scene orientation-${state.orientation}`;
  els.orientation.textContent = `Vista ${state.orientation}°`;
  $$('.slot').forEach(slot => {
    const slotId = slot.dataset.slot;
    slot.classList.remove('occupied', 'error');
    const occupied = Object.entries(state.installed).some(([type, componentId]) => catalog.components[componentId]?.targetSlot === slotId || (slotId === 'cpu_socket' && ['cpu', 'cooler'].includes(type)));
    if (occupied) slot.classList.add('occupied');
  });

  const evaluation = evaluateSystem(state);
  if (evaluation.knownFault === 'ram_not_seated') $('.ram-slot').classList.add('error');
  if (evaluation.knownFault === 'cpu_eps_missing') $('.eps-slot').classList.add('error');
  if (evaluation.knownFault === 'sata_data_disconnected') $('.sata-slot').classList.add('error');
  if (evaluation.knownFault === 'bad_thermal_paste') $('.cpu-slot').classList.add('error');

  renderCables();
}

function renderCables() {
  els.cablesLayer.innerHTML = '';
  const cableSpecs = [
    { key: 'ATX_24_PIN', x: 500, y: 140, w: 110, rot: 8 },
    { key: 'EPS_CPU_8_PIN', x: 96, y: 78, w: 150, rot: 18 },
    { key: 'SATA_DATA', x: 430, y: 280, w: 140, rot: -8 },
    { key: 'PCIE_GPU_8_PIN', x: 180, y: 330, w: 170, rot: 5 }
  ];
  cableSpecs.forEach(spec => {
    if (!state.connections[spec.key]) return;
    const cable = document.createElement('div');
    cable.className = 'cable';
    cable.style.left = `${spec.x}px`;
    cable.style.top = `${spec.y}px`;
    cable.style.width = `${spec.w}px`;
    cable.style.transform = `rotate(${spec.rot}deg)`;
    els.cablesLayer.appendChild(cable);
  });
}

function renderInspector() {
  const evaluation = evaluateSystem(state);
  els.post.textContent = evaluation.post ? 'Correcto' : 'Fallido';
  els.boot.textContent = evaluation.boot ? 'Correcto' : 'Bloqueado';
  els.watts.textContent = `${evaluation.peakWatts} W`;
  els.temp.textContent = `${evaluation.cpuTemp} °C`;
  els.score.textContent = `${state.xp} XP`;
  els.modeLabel.textContent = state.mode === 'assembly' ? 'Guiado' : 'Taller';
  els.log.innerHTML = state.log.map(item => `<li><span class="${item.level}">${item.at}</span> · ${item.message}</li>`).join('');
}

function setMode(mode) {
  state.mode = mode;
  els.assemblyButton.classList.toggle('active', mode === 'assembly');
  els.diagnosticButton.classList.toggle('active', mode === 'diagnostic');
  if (mode === 'diagnostic') {
    const faults = ['ram_not_seated', 'sata_data_disconnected', 'bad_thermal_paste', 'bad_sectors'];
    state.selectedScenarioFault = faults[Math.floor(Math.random() * faults.length)];
    state.log.unshift({ level: 'warn', at: new Date().toLocaleTimeString('es-ES'), message: 'Modo taller activado: se ha inyectado una avería. Usa herramientas para localizarla.' });
  } else {
    state.selectedScenarioFault = null;
    state.log.unshift({ level: 'ok', at: new Date().toLocaleTimeString('es-ES'), message: 'Modo montaje activado: construye el PC y valida compatibilidad.' });
  }
  render();
}

$('#rotate-left').addEventListener('click', () => { state.orientation = (state.orientation + 270) % 360; render(); });
$('#rotate-right').addEventListener('click', () => { state.orientation = (state.orientation + 90) % 360; render(); });
$('#power-on').addEventListener('click', () => { powerOn(state); render(); });
$('#reset-build').addEventListener('click', () => { state = createInitialState(); render(); });
els.assemblyButton.addEventListener('click', () => setMode('assembly'));
els.diagnosticButton.addEventListener('click', () => setMode('diagnostic'));
$$('[data-tool]').forEach(button => button.addEventListener('click', () => { runDiagnosticTool(state, button.dataset.tool); render(); }));

state.log.unshift({ level: 'ok', at: new Date().toLocaleTimeString('es-ES'), message: 'Bienvenida/o: instala componentes, gira el escenario y enciende para comprobar fallos.' });
render();
