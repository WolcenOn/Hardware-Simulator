import { catalog, faultLibrary } from './data.js';

export function createInitialState() {
  return {
    mode: 'assembly',
    orientation: 0,
    xp: 0,
    selectedScenarioFault: null,
    installed: {},
    installationStates: {},
    connections: {
      ATX_24_PIN: false,
      EPS_CPU_8_PIN: false,
      SATA_DATA: false,
      SATA_POWER: false,
      PCIE_GPU_8_PIN: false
    },
    thermalPasteQuality: 1,
    log: []
  };
}

export function installComponent(state, componentId) {
  const component = catalog.components[componentId];
  if (!component) return addLog(state, 'error', `Componente desconocido: ${componentId}`);

  const slot = catalog.slots[component.targetSlot];
  if (!slot || !slot.accepts.includes(component.type)) {
    return addLog(state, 'error', `${component.displayName} no puede colocarse en ese punto del montaje.`);
  }

  if (component.type === 'motherboard' && !isInstalled(state, 'case')) {
    return addLog(state, 'warn', 'Primero instala la caja para poder montar la placa base sobre sus separadores.');
  }
  if (['cpu', 'cooler', 'ram', 'gpu', 'storage'].includes(component.type) && !isInstalled(state, 'motherboard')) {
    return addLog(state, 'warn', `Antes de instalar ${component.displayName}, monta la placa base.`);
  }

  const compatibilityError = checkCompatibility(state, component);
  if (compatibilityError) return addLog(state, 'error', compatibilityError);

  const key = component.type === 'cooler' ? 'cooler' : component.type;
  state.installed[key] = componentId;
  state.installationStates[key] = defaultInstallationState(component.type);
  autoConnectSafeCables(state, component.type);
  addLog(state, 'ok', `${component.displayName} instalado. ${feedbackFor(component.type)}`);
  state.xp += 10;
  return state;
}

function defaultInstallationState(type) {
  if (type === 'ram') return { properlySeated: false, clipsLocked: false };
  if (type === 'cooler') return { mounted: true, thermalPasteQuality: 1 };
  if (type === 'cpu') return { properlySeated: true, retentionArmLocked: true, pinsBent: false };
  return { properlySeated: true };
}

function autoConnectSafeCables(state, type) {
  if (type === 'motherboard') state.connections.ATX_24_PIN = true;
  if (type === 'storage') state.connections.SATA_POWER = true;
  if (type === 'gpu') state.connections.PCIE_GPU_8_PIN = true;
}

export function performAction(state, action) {
  if (action === 'seat_ram' && state.installationStates.ram) {
    state.installationStates.ram.properlySeated = true;
    state.installationStates.ram.clipsLocked = true;
    state.xp += 8;
    return addLog(state, 'ok', 'RAM reencajada correctamente: ambos clips quedan cerrados.');
  }
  if (action === 'connect_eps') {
    state.connections.EPS_CPU_8_PIN = true;
    state.xp += 8;
    return addLog(state, 'ok', 'Cable EPS CPU 8 pin conectado.');
  }
  if (action === 'connect_sata') {
    state.connections.SATA_DATA = true;
    state.xp += 8;
    return addLog(state, 'ok', 'Cable SATA de datos conectado.');
  }
  if (action === 'bad_paste') {
    state.thermalPasteQuality = 0.25;
    return addLog(state, 'warn', 'Has aplicado poca pasta térmica. El sistema podría sobrecalentarse.');
  }
  if (action === 'good_paste') {
    state.thermalPasteQuality = 1;
    state.xp += 8;
    return addLog(state, 'ok', 'Pasta térmica aplicada correctamente.');
  }
  return state;
}

function checkCompatibility(state, component) {
  const motherboard = getInstalledComponent(state, 'motherboard');
  if (!motherboard) return null;
  if (component.type === 'cpu' && component.compatible.socket !== motherboard.compatible.socket) {
    return `CPU incompatible: socket ${component.compatible.socket} frente a placa ${motherboard.compatible.socket}.`;
  }
  if (component.type === 'ram' && component.compatible.memoryType !== motherboard.compatible.memoryType) {
    return `RAM incompatible: ${component.compatible.memoryType} no encaja en placa ${motherboard.compatible.memoryType}.`;
  }
  return null;
}

export function evaluateSystem(state) {
  const faults = [];
  const peakWatts = calculatePeakWatts(state);
  const psu = getInstalledComponent(state, 'psu');

  if (!isInstalled(state, 'case')) faults.push('missing_case');
  if (!isInstalled(state, 'motherboard')) faults.push('missing_motherboard');
  if (!isInstalled(state, 'cpu')) faults.push('missing_cpu');
  if (!isInstalled(state, 'ram')) faults.push('missing_ram');
  if (!isInstalled(state, 'psu')) faults.push('missing_psu');

  if (state.installationStates.ram && !state.installationStates.ram.properlySeated) faults.push('ram_not_seated');
  if (isInstalled(state, 'motherboard') && isInstalled(state, 'psu') && !state.connections.EPS_CPU_8_PIN) faults.push('cpu_eps_missing');
  if (isInstalled(state, 'storage') && !state.connections.SATA_DATA) faults.push('sata_data_disconnected');
  if (state.thermalPasteQuality < 0.7 && isInstalled(state, 'cpu') && isInstalled(state, 'cooler')) faults.push('bad_thermal_paste');
  if (psu && peakWatts * 1.25 > psu.electrical.maxWatts) faults.push('psu_overload');
  if (state.selectedScenarioFault) faults.push(state.selectedScenarioFault);

  const knownFault = faults.find(f => faultLibrary[f]);
  const blockingMissing = faults.find(f => f.startsWith('missing_'));

  return {
    faults,
    knownFault,
    peakWatts,
    psuLoadPercent: psu ? Math.round((peakWatts / psu.electrical.maxWatts) * 100) : 0,
    post: !blockingMissing && !['ram_not_seated', 'cpu_eps_missing'].includes(knownFault),
    boot: !blockingMissing && !['ram_not_seated', 'cpu_eps_missing', 'sata_data_disconnected'].includes(knownFault),
    cpuTemp: estimateCpuTemp(state, knownFault)
  };
}

export function runDiagnosticTool(state, toolId) {
  const evaluation = evaluateSystem(state);
  if (!evaluation.knownFault) {
    state.xp += 3;
    return addLog(state, 'ok', `${catalog.diagnosticTools[toolId]}: no detecta averías críticas en este momento.`);
  }
  const fault = faultLibrary[evaluation.knownFault];
  const result = fault.tools[toolId] || 'Esta herramienta no aporta información concluyente para esta avería.';
  state.xp += 6;
  return addLog(state, fault.severity === 'critical' ? 'error' : 'warn', `${catalog.diagnosticTools[toolId]}: ${result}`);
}

export function powerOn(state) {
  const evaluation = evaluateSystem(state);
  if (evaluation.faults.some(f => f.startsWith('missing_'))) {
    return addLog(state, 'error', `Montaje incompleto: ${evaluation.faults.filter(f => f.startsWith('missing_')).join(', ')}.`);
  }
  if (evaluation.knownFault) {
    const fault = faultLibrary[evaluation.knownFault];
    return addLog(state, fault.severity === 'critical' ? 'error' : 'warn', `Síntoma al encender: ${summarizeSymptoms(fault)} Pista: usa herramientas de diagnóstico.`);
  }
  state.xp += 15;
  return addLog(state, 'ok', 'El PC completa POST, detecta disco de arranque y entra al sistema operativo.');
}

function summarizeSymptoms(fault) {
  const s = fault.symptoms;
  if (s.debugLed) return `LED ${s.debugLed}, POST ${s.post ? 'correcto' : 'fallido'}.`;
  if (s.screenMessage) return `${s.screenMessage}.`;
  if (s.thermalShutdown) return `apagado térmico bajo carga.`;
  if (s.shutdownUnderLoad) return `apagado repentino al exigir CPU/GPU.`;
  if (s.osPerformance) return `sistema muy lento y errores de disco.`;
  return 'comportamiento anómalo.';
}

function feedbackFor(type) {
  const map = {
    case: 'Buen inicio: el chasis define compatibilidad física y flujo de aire.',
    motherboard: 'Comprueba siempre separadores y conectores principales.',
    cpu: 'Recuerda alinear la marca del socket y bloquear la palanca.',
    cooler: 'La transferencia térmica depende del contacto y la pasta.',
    ram: 'Ahora debes encajarla hasta cerrar ambos clips.',
    storage: 'Falta conectar datos SATA si quieres que arranque desde este SSD.',
    gpu: 'La GPU puede disparar el consumo pico del sistema.',
    psu: 'Revisa margen de potencia, conectores y estabilidad de 12 V.'
  };
  return map[type] || '';
}

export function addLog(state, level, message) {
  state.log.unshift({ level, message, at: new Date().toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit', second: '2-digit' }) });
  state.log = state.log.slice(0, 24);
  return state;
}

export function calculatePeakWatts(state) {
  return Object.values(state.installed).reduce((sum, id) => sum + (catalog.components[id]?.electrical?.peakWatts || 0), 0);
}

function estimateCpuTemp(state, knownFault) {
  if (knownFault === 'bad_thermal_paste') return 106;
  if (!isInstalled(state, 'cpu')) return 35;
  if (!isInstalled(state, 'cooler')) return 98;
  return state.thermalPasteQuality < 0.7 ? 96 : 42;
}

export function isInstalled(state, type) {
  return Boolean(state.installed[type]);
}

export function getInstalledComponent(state, type) {
  return catalog.components[state.installed[type]] || null;
}
