# PC Lab: Simulador de Montaje y Diagnóstico de PC

Prototipo web estático para enseñar montaje de ordenadores y diagnóstico de averías de hardware.

## Qué incluye

- Interfaz isométrica 2.5D con rotación en pasos de 90°.
- Catálogo inicial de componentes: caja, placa, CPU, disipador, RAM, GPU, SSD SATA y fuentes.
- Motor de reglas en JavaScript para compatibilidad, consumo, conexiones y errores de montaje.
- Modo montaje y modo diagnóstico/taller con averías inyectadas.
- Herramientas virtuales: inspección visual, pitidos BIOS, multímetro, SMART y test de estrés.
- Datos editables en `/data` y lógica principal en `/js`.

## Estructura

```txt
/
  index.html
  .nojekyll
  css/styles.css
  js/app.js
  js/data.js
  js/rulesEngine.js
  data/components/components.json
  data/rules/rules.json
  data/faults/faults.json
  data/scenarios/guided-assembly-basic.json
```

## Ejecutar en local

Por ser una app con módulos ES, lo más cómodo es servir la carpeta con un servidor estático:

```bash
python3 -m http.server 8000
```

Después abre:

```txt
http://localhost:8000
```

## Publicar en GitHub Pages

1. Crea un repositorio en GitHub.
2. Sube todo el contenido de esta carpeta a la raíz del repositorio.
3. Ve a `Settings > Pages`.
4. En `Build and deployment`, selecciona `Deploy from a branch`.
5. Elige la rama `main` y carpeta `/root`.
6. Guarda la configuración.

GitHub Pages busca un archivo de entrada como `index.html` en la fuente publicada. Este proyecto ya lo incluye en la raíz.

## Siguiente evolución recomendada

- Sustituir CSS isométrico por sprites SVG dibujados a mano.
- Separar escenarios por niveles y rúbricas de evaluación.
- Añadir persistencia local con `localStorage`.
- Añadir drag & drop real para componentes.
- Migrar a TypeScript cuando el motor de reglas crezca.
- Añadir tests unitarios para compatibilidad y diagnóstico.
